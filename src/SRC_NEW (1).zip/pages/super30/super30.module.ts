import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Super30Page } from './super30';

@NgModule({
  declarations: [
    Super30Page,
  ],
  imports: [
    IonicPageModule.forChild(Super30Page),
  ],
})
export class Super30PageModule {}
