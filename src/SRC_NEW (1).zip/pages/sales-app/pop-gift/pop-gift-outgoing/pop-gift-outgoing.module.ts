import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PopGiftOutgoingPage } from './pop-gift-outgoing';

@NgModule({
  declarations: [
    PopGiftOutgoingPage,
  ],
  imports: [
    IonicPageModule.forChild(PopGiftOutgoingPage),
  ],
})
export class PopGiftOutgoingPageModule {}
