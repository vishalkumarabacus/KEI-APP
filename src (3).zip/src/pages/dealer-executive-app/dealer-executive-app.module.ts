import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DealerExecutiveAppPage } from './dealer-executive-app';

@NgModule({
  declarations: [
    DealerExecutiveAppPage,
  ],
  imports: [
    IonicPageModule.forChild(DealerExecutiveAppPage),
  ],
})
export class DealerExecutiveAppPageModule {}
